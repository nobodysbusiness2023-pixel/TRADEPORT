# TradePort Market Website Design

## Overview
- **Motion Style**: "Fluid Commerce" - Kinetic, bouncy, and deeply satisfying micro-interactions.
- **Animation Intensity**: Ultra-Dynamic
- **Technology Stack**: React, GSAP (ScrollTrigger, Flip), WebGL (for distortion effects), CSS Modules.

## Brand Foundation
- **Colors**:
  - Primary Blue: #0056d3
  - Primary Dark: #121212
  - Primary White: #ffffff
  - Accent Yellow: #ffe81c (Used for "New" badges, highlights)
  - Dark Gray: #26272b
  - Medium Gray: #777777
  - Light Gray: #f7f7f7
  - Border Gray: #e2e2e2
  - Error Red: #fc372d
  - Success Green: #03cd69
  - Info Blue: #3186c4
- **Typography**:
  - Primary Font: "Inter" (Google Fonts)
  - Weights: 400 (Regular), 500 (Medium), 600 (Semi-bold), 700 (Bold)
- **Core Message**: Modern, trustworthy, and user-friendly marketplace.

## Global Motion System

### Animation Timing
- **Easing Library**:
  - `custom-expo`: `cubic-bezier(0.16, 1, 0.3, 1)` for entrances.
  - `custom-bounce`: `cubic-bezier(0.34, 1.56, 0.64, 1)` for hover states.
  - `smooth-linear`: `linear` for continuous marquees.
- **Duration Scale**:
  - Micro-interactions: 0.2s - 0.3s
  - Layout shifts: 0.6s - 0.8s
  - Page transitions: 1.0s

### Continuous Effects
- **Floating Elements**: Subtle sine-wave vertical motion on isolated elements (badges, icons).
- **Living Gradients**: Slow-moving background gradients on specific highlighted cards.
- **Cursor Follower**: Magnetic influence on buttons and interactive cards.

### Scroll Engine
- **Velocity Skew**: Text and images skew slightly (max 5deg) based on scroll speed.
- **Parallax Layers**: Background elements move at 20% speed of scroll.
- **Reveal**: Elements do not just fade in; they unmask from bottom or slide up with elastic recoil.

## Section 1: Navigation Bar

### Layout
**Dynamic Sticky Header**:
- Initially transparent, transforms to solid white with shadow on scroll.
- The logo pins to the top-left.
- "Sell" button is magnetic and pulses gently.

### Motion Choreography
#### Entrance Sequence
| Element | Animation | Values | Duration | Delay | Easing |
|---------|-----------|--------|----------|-------|--------|
| Logo | Slide Down | Y: -100% → 0% | 0.8s | 0.0s | custom-expo |
| Nav Links | Stagger Fade | Opacity: 0 → 1 | 0.6s | 0.2s | linear |
| Sell Button | Scale In | Scale: 0 → 1 | 0.5s | 0.4s | custom-bounce |

#### Interaction Effects
- **Search Bar**: On focus, the background expands smoothly (width 100% → 110%) and the border glows #0056d3.
- **Dropdowns**: Unfold like origami (3D rotation X) rather than simple fade.
- **Cart Icon**: On item add, the icon "jumps" and a particle trail fires from the product to the cart icon.

## Section 2: Hero Search Section

### Layout
**Immersive Search Portal**:
- Full-viewport height (min-height: 100vh).
- **Background**: A dynamic WebGL mesh gradient using the brand palette (#0056d3, #f7f7f7) that reacts to mouse movement.
- **Content**: Vertically centered, massive search bar dominates the view.

### Content
- **Headline**: "The marketplace built for you."
- **Subheadline**: "Buy and sell everything from electronics to collectibles."

### Motion Choreography
#### Entrance Sequence
- **Headline**: Split by lines. Each line slides up from a masked container with 0.1s stagger.
- **Search Bar**: Expands from center (width 0% → 100%) with elastic overshoot.

#### Interaction Effects
- **Search Input**: As user types, suggested keywords (pills) fly in from the right, orbiting the input field before settling.
- **Submit Button**: Magnetic pull on hover. On click, transforms into a loading spinner, then a "check" mark.

## Section 3: Featured Categories

### Layout
**Orbital Constellation**:
- Instead of a static grid, categories are arranged in a semi-circular "cloud" formation.
- On mobile, it condenses to a horizontal scroll snap.

### Images (Preserved)
- **Electronics**: Flat screen TV, minimalist icon.
- **Computers & Tablets**: Laptop/Tablet, minimalist icon.
- **Cell Phones**: Smartphone, minimalist icon.
- *All 16 category images preserved exactly.*

### Motion Choreography
#### Scroll Effects
- **Entrance**: Items float up from bottom with varying speeds (parallax).
- **Continuous**: Each icon floats gently (independent sine waves) to feel "alive".

#### Interaction Effects
- **Hover**: The category card scales up (1.1x) and tilts 3D towards the cursor (perspective 1000px).
- **Icon**: The SVG icon inside performs a "draw" animation (stroke-dashoffset) on hover.

## Section 4: Latest Products

### Layout
**Drifting Masonry Grid**:
- A 4-column layout where columns scroll at slightly different speeds (Parallax columns).
- Column 1 & 3 scroll at 1.0x speed. Column 2 & 4 scroll at 1.1x speed, creating a dynamic shearing effect.

### Content
- **Header**: "Latest Products" with a "View All" button.
- **Product Cards**: Thumbnail, Title, Price, Location, Condition, Seller Info.

### Images (Preserved)
- **Product Images**: All original product photos preserved.
- **Badges**: "New" (Yellow #ffe81c), "Used" (Dark Gray #26272b).

### Motion Choreography
#### Scroll Effects
- **Cards**: As cards enter the viewport, they scale up from 0.9 → 1.0 and opacity 0 → 1.
- **Images**: Images have a subtle "zoom out" effect (scale 1.2 → 1.0) on reveal.

#### Interaction Effects
- **Card Hover**:
  - **Lift**: Card translates Y -10px and shadow expands.
  - **Image**: Scales 1.1x within its container.
  - **Badge**: The "New" badge rotates 360 degrees rapidly (spring physics).
- **Add to Cart**: Button morphs from "Add to Cart" → "✓ Added" with a confetti burst.

## Section 5: How It Works

### Layout
**Connected Pathway**:
- A horizontal layout where steps are connected by an animated SVG path line.
- The line draws itself from left to right as the user scrolls down.

### Content
- **Step 1**: "Create Listing" (Icon: Post/Edit)
- **Step 2**: "Get Discovered" (Icon: Search)
- **Step 3**: "Make Money" (Icon: Cash)

### Motion Choreography
#### Scroll Effects
- **Path Drawing**: The connecting line's stroke-dashoffset animates based on scroll progress.
- **Steps**: When the line reaches a step, the step icon "pops" (scale 0 → 1.2 → 1).

#### Interaction Effects
- **Hover**: Hovering a step highlights the connecting path segment in Primary Blue.

## Section 6: Why Choose Us

### Layout
**Interactive Accordion**:
- Vertical list of benefits.
- Instead of static text, each benefit is a large, tappable strip.
- **Background**: Dark Gray #26272b.

### Motion Choreography
#### Interaction Effects
- **Hover/Tap**: The selected benefit expands vertically.
- **Icon**: The icon (Checkmark) draws itself using SVG stroke animation.
- **Text**: Description text fades in and slides down inside the expanded area.

## Section 7: Testimonials

### Layout
**Infinite Kinetic Carousel**:
- A single row of cards that scrolls infinitely to the left.
- Users can drag to speed up or slow down the scroll.

### Content
- **Cards**: Quote, Name, Company.

### Motion Choreography
- **Continuous**: Constant linear movement (velocity depends on drag interaction).
- **Entrance**: Cards slide in from the right, staggering their entry.

## Section 8: CTA Section

### Layout
**Ripple Focus**:
- Centered content over a subtle animated background.
- **Background**: White, but with a subtle, slow-pulsing radial gradient ring behind the main button.

### Content
- "Ready to sell your stuff?"
- "Post your first ad for $1 only"

### Motion Choreography
- **Button**: The "Sell Now" button has a "ripple" effect radiating outward every 3 seconds to draw attention.
- **Hover**: The button scales up and the background ring expands rapidly.

## Section 9: Footer

### Layout
**Curtain Reveal**:
- The footer is fixed at the bottom of the viewport with `z-index: -1`.
- The preceding section (CTA) has a `margin-bottom` equal to the footer height.
- As the user scrolls to the end, the CTA section lifts up like a curtain to reveal the footer.

### Content
- **Columns**: Brand info, Categories, Help, Social Links.
- **Social Icons**: Circular buttons.

### Motion Choreography
- **Social Icons**: On hover, they don't just change color; they rotate 360 degrees and the background fills with #0056d3.

## Technical Implementation Notes

### Required Libraries
- **GSAP**: Core animation engine (ScrollTrigger for timeline control).
- **Lenis**: For smooth scroll momentum (essential for the velocity skew effects).
- **Three.js / React-Three-Fiber**: For the Hero mesh gradient (if WebGL is available, falls back to CSS gradient).

### Critical Performance Rules
- ✅ **Use transform3d()** and `will-change: transform` for all moving cards.
- ✅ **Debounce** resize events.
- ❌ **No layout thrashing**: Do not animate `width`/`height` on the Masonry grid; use `scale` or `translate`.
- ❌ **Limit WebGL**: Only use WebGL in the Hero section; everything else uses CSS transforms.

### Accessibility
- **Prefers-Reduced-Motion**:
  - Disable parallax.
  - Disable velocity skew.
  - Change "fly-in" entrances to simple opacity fades.
  - Stop infinite marquee.

## Enhancement Rules Verification
- **Hero**: Added WebGL background (Full redesign).
- **Images**: All original images preserved.
- **Colors**: All original hex codes preserved.
- **Typography**: Inter font preserved.
- **Layout**: Transformed from static grid to Orbital/Drifting/Masonry layouts.
- **Motion**: Added ScrollTrigger, Parallax, and Magnetic interactions.
