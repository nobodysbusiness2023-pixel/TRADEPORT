import { useState } from 'react';
import { AppProvider } from '@/store/AppContext';
import Header from '@/sections/Header';
import Hero from '@/sections/Hero';
import FeaturedCategories from '@/sections/FeaturedCategories';
import HowItWorks from '@/sections/HowItWorks';
import WhyChooseUs from '@/sections/WhyChooseUs';
import Testimonials from '@/sections/Testimonials';
import CTA from '@/sections/CTA';
import Footer from '@/sections/Footer';
import CategorySidebar from '@/sections/CategorySidebar';
import ProductGrid from '@/sections/ProductGrid';
import ProductDetailModal from '@/sections/ProductDetailModal';
import Cart from '@/sections/Cart';
import SellerDashboard from '@/sections/SellerDashboard';
import ListingModal from '@/sections/ListingModal';
import type { Product } from '@/types';

function AppContent() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);

  const handleViewProductDetails = (product: Product) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      
      {/* Featured Categories */}
      <FeaturedCategories />
      
      {/* How It Works */}
      <HowItWorks />
      
      {/* Why Choose Us */}
      <WhyChooseUs />
      
      {/* Main Marketplace */}
      <section className="py-16 bg-tradeport-light">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar */}
            <CategorySidebar />
            
            {/* Product Grid */}
            <ProductGrid onViewDetails={handleViewProductDetails} />
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <Testimonials />
      
      {/* CTA */}
      <CTA />
      
      {/* Footer */}
      <Footer />

      {/* Modals & Overlays */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
      />
      <Cart />
      <SellerDashboard
        isOpen={false} // Controlled by context
        onClose={() => {}}
        onCreateListing={() => {}}
      />
      <ListingModal isOpen={false} onClose={() => {}} />
    </div>
  );
}

function AppWithContext() {
  const [isSellerDashboardOpen, setIsSellerDashboardOpen] = useState(false);
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);

  return (
    <AppProvider>
      <div className="min-h-screen bg-white">
        <AppContent />
        <SellerDashboard
          isOpen={isSellerDashboardOpen}
          onClose={() => setIsSellerDashboardOpen(false)}
          onCreateListing={() => {
            setIsSellerDashboardOpen(false);
            setIsListingModalOpen(true);
          }}
        />
        <ListingModal
          isOpen={isListingModalOpen}
          onClose={() => setIsListingModalOpen(false)}
        />
      </div>
    </AppProvider>
  );
}

export default AppWithContext;
