import type { Product, Category, Testimonial, BannerItem, UserListing } from '@/types';

export const categories: Category[] = [
  { id: 'electronics', name: 'Electronics', icon: 'tv', productCount: 1250, subcategories: ['TVs', 'Audio', 'Cameras', 'Accessories'] },
  { id: 'computers', name: 'Computers & Tablets', icon: 'laptop', productCount: 890, subcategories: ['Laptops', 'Desktops', 'Tablets', 'Monitors'] },
  { id: 'phones', name: 'Cell Phones', icon: 'smartphone', productCount: 2100, subcategories: ['Smartphones', 'Cases', 'Chargers', 'Accessories'] },
  { id: 'appliances', name: 'Appliances', icon: 'chef-hat', productCount: 650, subcategories: ['Kitchen', 'Laundry', 'Vacuums', 'Small Appliances'] },
  { id: 'collectibles', name: 'Collectibles', icon: 'gem', productCount: 3400, subcategories: ['Cards', 'Figures', 'Coins', 'Art'] },
  { id: 'jewelry', name: 'Jewelry & Watches', icon: 'watch', productCount: 1800, subcategories: ['Watches', 'Necklaces', 'Rings', 'Earrings'] },
  { id: 'clothing', name: 'Clothing & Accessories', icon: 'shirt', productCount: 4500, subcategories: ['Men', 'Women', 'Kids', 'Shoes'] },
  { id: 'sporting', name: 'Sporting Goods', icon: 'basketball', productCount: 1200, subcategories: ['Fitness', 'Outdoor', 'Team Sports', 'Water Sports'] },
  { id: 'home', name: 'Home & Garden', icon: 'home', productCount: 2800, subcategories: ['Furniture', 'Decor', 'Kitchen', 'Garden'] },
  { id: 'tools', name: 'Tools', icon: 'wrench', productCount: 950, subcategories: ['Power Tools', 'Hand Tools', 'Tool Storage', 'Hardware'] },
  { id: 'automotive', name: 'Automotive', icon: 'car', productCount: 1100, subcategories: ['Parts', 'Accessories', 'Tools', 'Tires'] },
  { id: 'games', name: 'Games & Consoles', icon: 'gamepad2', productCount: 780, subcategories: ['Consoles', 'Games', 'Controllers', 'Accessories'] },
  { id: 'toys', name: 'Toys', icon: 'puzzle', productCount: 1600, subcategories: ['Action Figures', 'Dolls', 'Educational', 'Outdoor'] },
  { id: 'books', name: 'Books & Audiobooks', icon: 'book', productCount: 3200, subcategories: ['Fiction', 'Non-Fiction', 'Textbooks', 'Audiobooks'] },
  { id: 'music', name: 'Music & Instruments', icon: 'music', productCount: 900, subcategories: ['Guitars', 'Keyboards', 'Drums', 'Vinyl'] },
  { id: 'health', name: 'Health & Beauty', icon: 'heart', productCount: 1400, subcategories: ['Skincare', 'Makeup', 'Vitamins', 'Personal Care'] },
  { id: 'pets', name: 'Pet Supplies', icon: 'paw-print', productCount: 700, subcategories: ['Dogs', 'Cats', 'Fish', 'Birds'] },
  { id: 'misc', name: 'Miscellaneous', icon: 'package', productCount: 500, subcategories: ['Office', 'Party', 'Storage', 'Other'] },
];

export const products: Product[] = [
  {
    id: '1',
    title: 'Samsung 65" 4K Smart TV - Crystal UHD',
    description: 'Experience stunning 4K resolution with this Samsung Smart TV. Features HDR support, built-in streaming apps, and voice control. Perfect for any living room setup.',
    price: 549.99,
    originalPrice: 799.99,
    image: '/product-tv.jpg',
    category: 'Electronics',
    condition: 'New',
    location: 'Los Angeles, CA',
    seller: { name: 'TechDeals Pro', rating: 4.9, reviews: 2847, verified: true },
    datePosted: '2026-01-15',
    featured: true,
    tags: ['4K', 'Smart TV', 'Samsung', 'HDR']
  },
  {
    id: '2',
    title: 'MacBook Pro 14" M3 Chip - Space Gray',
    description: 'Latest MacBook Pro with M3 chip. 16GB RAM, 512GB SSD. Perfect for professionals and creatives. Excellent condition, barely used.',
    price: 1599.00,
    originalPrice: 1999.00,
    image: '/product-laptop.jpg',
    category: 'Computers & Tablets',
    condition: 'Used',
    location: 'San Francisco, CA',
    seller: { name: 'AppleReseller', rating: 4.8, reviews: 1523, verified: true },
    datePosted: '2026-01-14',
    featured: true,
    tags: ['Apple', 'MacBook', 'M3', 'Professional']
  },
  {
    id: '3',
    title: 'iPhone 15 Pro Max - Natural Titanium 256GB',
    description: 'Brand new iPhone 15 Pro Max in Natural Titanium. Unlocked, 256GB storage. Comes with original box and accessories.',
    price: 1099.00,
    image: '/product-phone.jpg',
    category: 'Cell Phones',
    condition: 'New',
    location: 'New York, NY',
    seller: { name: 'MobileFirst', rating: 4.9, reviews: 3421, verified: true },
    datePosted: '2026-01-16',
    featured: true,
    tags: ['iPhone', 'Apple', '5G', 'Unlocked']
  },
  {
    id: '4',
    title: 'LG French Door Refrigerator - Stainless Steel',
    description: 'Large capacity French door refrigerator with ice maker and water dispenser. Energy efficient, 27 cu ft. Minor scratches but works perfectly.',
    price: 899.00,
    originalPrice: 1899.00,
    image: '/product-fridge.jpg',
    category: 'Appliances',
    condition: 'Used',
    location: 'Chicago, IL',
    seller: { name: 'HomeApplianceHub', rating: 4.7, reviews: 892, verified: false },
    datePosted: '2026-01-12',
    tags: ['LG', 'Refrigerator', 'Kitchen', 'Energy Star']
  },
  {
    id: '5',
    title: 'Vintage Record Player - Retro Wood Design',
    description: 'Beautiful vintage-style record player with built-in speakers. Plays 33, 45, and 78 RPM records. Bluetooth connectivity included.',
    price: 149.99,
    originalPrice: 249.99,
    image: '/product-record-player.jpg',
    category: 'Collectibles',
    condition: 'Refurbished',
    location: 'Austin, TX',
    seller: { name: 'RetroSounds', rating: 4.9, reviews: 567, verified: true },
    datePosted: '2026-01-13',
    featured: true,
    tags: ['Vintage', 'Turntable', 'Bluetooth', 'Retro']
  },
  {
    id: '6',
    title: 'Rolex Datejust 41 - Oystersteel & Gold',
    description: 'Authentic Rolex Datejust 41 with champagne dial. Oystersteel and yellow gold combination. Complete with box and papers.',
    price: 12500.00,
    image: '/product-watch.jpg',
    category: 'Jewelry & Watches',
    condition: 'Used',
    location: 'Miami, FL',
    seller: { name: 'LuxuryTimepieces', rating: 5.0, reviews: 234, verified: true },
    datePosted: '2026-01-10',
    tags: ['Rolex', 'Luxury', 'Gold', 'Authentic']
  },
  {
    id: '7',
    title: 'Designer Denim Jacket - Men\'s Medium',
    description: 'Premium designer denim jacket in excellent condition. Dark wash, classic fit. Perfect for any casual outfit.',
    price: 89.00,
    originalPrice: 195.00,
    image: '/product-jacket.jpg',
    category: 'Clothing & Accessories',
    condition: 'Used',
    location: 'Seattle, WA',
    seller: { name: 'FashionForward', rating: 4.8, reviews: 1123, verified: false },
    datePosted: '2026-01-15',
    tags: ['Denim', 'Jacket', 'Designer', 'Men']
  },
  {
    id: '8',
    title: 'Wilson Official NBA Basketball',
    description: 'Official NBA game ball. Size 7, composite leather. Perfect grip and bounce. Used but in great condition.',
    price: 45.00,
    originalPrice: 69.99,
    image: '/product-basketball.jpg',
    category: 'Sporting Goods',
    condition: 'Used',
    location: 'Boston, MA',
    seller: { name: 'SportsZone', rating: 4.7, reviews: 2156, verified: true },
    datePosted: '2026-01-14',
    tags: ['NBA', 'Basketball', 'Wilson', 'Official']
  },
  {
    id: '9',
    title: 'DeWalt 20V Cordless Drill Kit',
    description: 'Complete DeWalt drill kit with 2 batteries, charger, and carrying case. Brushless motor, high torque. Like new condition.',
    price: 129.00,
    originalPrice: 199.00,
    image: '/product-drill.jpg',
    category: 'Tools',
    condition: 'Used',
    location: 'Denver, CO',
    seller: { name: 'ToolTimePro', rating: 4.9, reviews: 876, verified: true },
    datePosted: '2026-01-11',
    tags: ['DeWalt', 'Cordless', 'Drill', '20V']
  },
  {
    id: '10',
    title: 'Garden Tool Set - 5 Pieces',
    description: 'Complete garden tool set including trowel, cultivator, weeder, fork, and transplanter. Ergonomic handles with hanging holes.',
    price: 29.99,
    originalPrice: 49.99,
    image: '/product-garden-tools.jpg',
    category: 'Home & Garden',
    condition: 'New',
    location: 'Portland, OR',
    seller: { name: 'GardenGuru', rating: 4.6, reviews: 543, verified: false },
    datePosted: '2026-01-16',
    tags: ['Garden', 'Tools', 'Set', 'Outdoor']
  },
  {
    id: '11',
    title: 'Sport Rim Alloy Wheels - Set of 4',
    description: '18-inch sport alloy wheels, 5x114.3 bolt pattern. Gloss black finish. Fits many Honda, Toyota, Nissan models.',
    price: 450.00,
    originalPrice: 699.00,
    image: '/product-wheel.jpg',
    category: 'Automotive',
    condition: 'Used',
    location: 'Las Vegas, NV',
    seller: { name: 'AutoPartsDirect', rating: 4.8, reviews: 1678, verified: true },
    datePosted: '2026-01-13',
    tags: ['Wheels', 'Alloy', 'Sport', '18 inch']
  },
  {
    id: '12',
    title: 'PlayStation 5 DualSense Controller - White',
    description: 'Official PS5 DualSense wireless controller. White color. Excellent haptic feedback and adaptive triggers. Barely used.',
    price: 49.00,
    originalPrice: 69.99,
    image: '/product-controller.jpg',
    category: 'Games & Consoles',
    condition: 'Used',
    location: 'San Diego, CA',
    seller: { name: 'GameHub', rating: 4.9, reviews: 2890, verified: true },
    datePosted: '2026-01-15',
    tags: ['PS5', 'Controller', 'Sony', 'Wireless']
  },
  {
    id: '13',
    title: 'Marvel Legends Action Figure - Spider-Man',
    description: 'Premium Marvel Legends Spider-Man figure with multiple accessories and interchangeable hands. Mint in box.',
    price: 34.99,
    originalPrice: 49.99,
    image: '/product-action-figure.jpg',
    category: 'Toys',
    condition: 'New',
    location: 'Orlando, FL',
    seller: { name: 'CollectorsCorner', rating: 4.9, reviews: 445, verified: true },
    datePosted: '2026-01-14',
    featured: true,
    tags: ['Marvel', 'Spider-Man', 'Action Figure', 'Legends']
  },
  {
    id: '14',
    title: 'Best-Selling Novel Collection - 5 Books',
    description: 'Collection of 5 best-selling novels in hardcover. Various genres, all in excellent condition. Perfect for book lovers.',
    price: 35.00,
    originalPrice: 75.00,
    image: '/product-books.jpg',
    category: 'Books & Audiobooks',
    condition: 'Used',
    location: 'Philadelphia, PA',
    seller: { name: 'BookNook', rating: 4.7, reviews: 789, verified: false },
    datePosted: '2026-01-12',
    tags: ['Books', 'Novels', 'Collection', 'Hardcover']
  },
  {
    id: '15',
    title: 'Yamaha Acoustic Guitar - F310',
    description: 'Beginner-friendly Yamaha acoustic guitar. Spruce top, rosewood fingerboard. Comes with gig bag and picks.',
    price: 149.00,
    originalPrice: 219.00,
    image: '/product-guitar.jpg',
    category: 'Music & Instruments',
    condition: 'Used',
    location: 'Nashville, TN',
    seller: { name: 'MusicExchange', rating: 4.8, reviews: 1234, verified: true },
    datePosted: '2026-01-11',
    tags: ['Yamaha', 'Guitar', 'Acoustic', 'Beginner']
  },
  {
    id: '16',
    title: 'Premium Anti-Aging Skincare Set',
    description: 'Luxury skincare set with retinol, vitamin C, and hyaluronic acid. Brand new, sealed packaging. 30-day supply.',
    price: 89.99,
    originalPrice: 149.99,
    image: '/product-skincare.jpg',
    category: 'Health & Beauty',
    condition: 'New',
    location: 'Scottsdale, AZ',
    seller: { name: 'BeautyBoutique', rating: 4.9, reviews: 2100, verified: true },
    datePosted: '2026-01-16',
    tags: ['Skincare', 'Anti-Aging', 'Luxury', 'Set']
  },
  {
    id: '17',
    title: 'Stainless Steel Pet Bowls - Set of 2',
    description: 'High-quality stainless steel pet food and water bowls. Non-slip rubber base. Dishwasher safe. Various sizes available.',
    price: 19.99,
    originalPrice: 29.99,
    image: '/product-pet-bowl.jpg',
    category: 'Pet Supplies',
    condition: 'New',
    location: 'Charlotte, NC',
    seller: { name: 'PetParadise', rating: 4.6, reviews: 987, verified: false },
    datePosted: '2026-01-15',
    tags: ['Pet', 'Bowl', 'Stainless Steel', 'Dog']
  },
  {
    id: '18',
    title: 'Vintage Comic Book - Amazing Fantasy #15',
    description: 'Highly collectible vintage comic book. Classic issue in protective sleeve. Great condition for its age.',
    price: 2500.00,
    image: '/product-comic.jpg',
    category: 'Collectibles',
    condition: 'Used',
    location: 'New York, NY',
    seller: { name: 'GoldenAgeComics', rating: 5.0, reviews: 156, verified: true },
    datePosted: '2026-01-10',
    tags: ['Comic', 'Vintage', 'Collectible', 'Marvel']
  },
  {
    id: '19',
    title: 'iPad Pro 12.9" M2 - WiFi 256GB',
    description: 'Latest iPad Pro with M2 chip. 12.9-inch Liquid Retina XDR display. Perfect for creative professionals and students.',
    price: 999.00,
    originalPrice: 1199.00,
    image: '/product-tablet.jpg',
    category: 'Computers & Tablets',
    condition: 'Refurbished',
    location: 'San Jose, CA',
    seller: { name: 'TabletWorld', rating: 4.8, reviews: 1678, verified: true },
    datePosted: '2026-01-13',
    featured: true,
    tags: ['iPad', 'Apple', 'M2', 'Pro']
  },
  {
    id: '20',
    title: 'Canon EOS R6 Mark II - Mirrorless Camera',
    description: 'Professional mirrorless camera body only. 24.2MP full-frame sensor. Excellent for photography and video.',
    price: 2199.00,
    originalPrice: 2499.00,
    image: '/product-camera.jpg',
    category: 'Electronics',
    condition: 'Used',
    location: 'Los Angeles, CA',
    seller: { name: 'CameraProShop', rating: 4.9, reviews: 892, verified: true },
    datePosted: '2026-01-12',
    tags: ['Canon', 'Camera', 'Mirrorless', 'Full Frame']
  },
  {
    id: '21',
    title: 'Apple AirPods Pro 2nd Generation',
    description: 'Latest AirPods Pro with USB-C. Active noise cancellation, adaptive transparency. Complete with case and all tips.',
    price: 179.00,
    originalPrice: 249.00,
    image: '/product-earbuds.jpg',
    category: 'Electronics',
    condition: 'Used',
    location: 'Austin, TX',
    seller: { name: 'AudioTech', rating: 4.8, reviews: 2134, verified: true },
    datePosted: '2026-01-14',
    tags: ['AirPods', 'Apple', 'Wireless', 'Noise Cancelling']
  },
  {
    id: '22',
    title: 'Keurig K-Supreme Plus Coffee Maker',
    description: 'Single-serve coffee maker with multi-stream technology. Brews multiple cup sizes. Black stainless steel finish.',
    price: 89.99,
    originalPrice: 149.99,
    image: '/product-coffee-maker.jpg',
    category: 'Appliances',
    condition: 'Refurbished',
    location: 'Portland, OR',
    seller: { name: 'CoffeeLovers', rating: 4.7, reviews: 1567, verified: false },
    datePosted: '2026-01-15',
    tags: ['Keurig', 'Coffee', 'Single Serve', 'Stainless']
  },
  {
    id: '23',
    title: 'Coach Leather Handbag - Brown',
    description: 'Authentic Coach leather handbag in classic brown. Medium size with multiple compartments. Excellent condition.',
    price: 195.00,
    originalPrice: 395.00,
    image: '/product-handbag.jpg',
    category: 'Clothing & Accessories',
    condition: 'Used',
    location: 'Chicago, IL',
    seller: { name: 'LuxuryBagsCo', rating: 4.9, reviews: 445, verified: true },
    datePosted: '2026-01-11',
    tags: ['Coach', 'Handbag', 'Leather', 'Designer']
  },
  {
    id: '24',
    title: 'Trek Mountain Bike - Hardtail 29"',
    description: 'High-performance mountain bike with 29-inch wheels. Front suspension, hydraulic disc brakes. Great for trails and commuting.',
    price: 450.00,
    originalPrice: 699.00,
    image: '/product-bike.jpg',
    category: 'Sporting Goods',
    condition: 'Used',
    location: 'Denver, CO',
    seller: { name: 'BikeWorld', rating: 4.8, reviews: 1890, verified: true },
    datePosted: '2026-01-13',
    featured: true,
    tags: ['Trek', 'Mountain Bike', '29er', 'Hardtail']
  },
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Mitchell',
    company: 'Small Business Owner',
    quote: 'TradePort Market has been a game-changer for my business. The $1 listing fee is incredibly fair, and I\'ve connected with so many great buyers!',
    avatar: 'SM'
  },
  {
    id: '2',
    name: 'James Rodriguez',
    company: 'Tech Enthusiast',
    quote: 'Finally, a marketplace that doesn\'t take a huge commission! I\'ve sold over 50 items here and keep 100% of my profits.',
    avatar: 'JR'
  },
  {
    id: '3',
    name: 'Emily Chen',
    company: 'Collector',
    quote: 'Found some rare collectibles at amazing prices. The direct seller communication makes transactions smooth and transparent.',
    avatar: 'EC'
  },
  {
    id: '4',
    name: 'Michael Thompson',
    company: 'Retailer',
    quote: 'The no-commission model is revolutionary. We\'ve moved a significant portion of our inventory here from other platforms.',
    avatar: 'MT'
  },
];

export const banners: BannerItem[] = [
  {
    id: '1',
    title: 'Welcome to TradePort Market',
    subtitle: 'The marketplace built for you. Buy and sell with zero commissions.',
    image: '/banner-1.jpg',
    cta: 'Start Selling',
    link: '/sell'
  },
  {
    id: '2',
    title: 'List Your Items for Just $1',
    subtitle: 'No commissions. No hidden fees. Keep 100% of your sales.',
    image: '/banner-2.jpg',
    cta: 'Learn More',
    link: '/how-it-works'
  },
  {
    id: '3',
    title: 'Featured Electronics Deals',
    subtitle: 'Find incredible deals on phones, laptops, and more.',
    image: '/banner-3.jpg',
    cta: 'Shop Now',
    link: '/category/electronics'
  },
];

export const userListings: UserListing[] = [
  {
    id: 'ul1',
    title: 'Vintage Record Player - Retro Wood Design',
    description: 'Beautiful vintage-style record player with built-in speakers.',
    price: 149.99,
    image: '/product-record-player.jpg',
    category: 'Collectibles',
    condition: 'Refurbished',
    location: 'Austin, TX',
    seller: { name: 'You', rating: 4.9, reviews: 23, verified: true },
    datePosted: '2026-01-13',
    status: 'Active',
    expiresAt: '2026-02-12',
    views: 156,
    renewals: 0,
    listingFee: 1.00,
    tags: ['Vintage', 'Turntable', 'Bluetooth']
  },
  {
    id: 'ul2',
    title: 'iPhone 15 Pro Max - Natural Titanium',
    description: 'Brand new iPhone 15 Pro Max, 256GB, unlocked.',
    price: 1099.00,
    image: '/product-phone.jpg',
    category: 'Cell Phones',
    condition: 'New',
    location: 'New York, NY',
    seller: { name: 'You', rating: 4.9, reviews: 23, verified: true },
    datePosted: '2025-12-20',
    status: 'Expired',
    expiresAt: '2026-01-19',
    views: 423,
    renewals: 1,
    listingFee: 1.00,
    tags: ['iPhone', 'Apple', '5G']
  },
];

export const whyChooseUs = [
  {
    title: 'Zero Commission',
    description: 'Keep 100% of your sales. We only charge a flat $1 listing fee per item every 30 days.'
  },
  {
    title: 'Direct Buyer-Seller Connection',
    description: 'Communicate directly with buyers. No middleman means better prices for everyone.'
  },
  {
    title: 'Simple & Transparent',
    description: 'No hidden fees, no complex pricing tiers. One flat fee, that\'s it.'
  },
  {
    title: 'Built for Everyone',
    description: 'Whether you\'re a casual seller or running a business, our platform works for you.'
  },
];

export const howItWorks = [
  {
    step: 1,
    title: 'Create Your Listing',
    description: 'Upload photos, add details, and set your price. Pay just $1 to list for 30 days.',
    icon: 'edit'
  },
  {
    step: 2,
    title: 'Get Discovered',
    description: 'Buyers browse and find your items. Our platform makes your listings visible to the right audience.',
    icon: 'search'
  },
  {
    step: 3,
    title: 'Make the Sale',
    description: 'Connect directly with buyers to complete the sale. Keep 100% of what you earn.',
    icon: 'dollar-sign'
  },
];

export const conditions = ['New', 'Used', 'Refurbished'] as const;
