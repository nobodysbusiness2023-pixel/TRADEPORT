import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/store/AppContext';

export default function CTA() {
  const { setIsListingModalOpen } = useAppContext();

  return (
    <section className="py-20 bg-tradeport-light relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-tradeport-blue/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-tradeport-yellow/10 rounded-full translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="w-full px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-tradeport-blue/10 text-tradeport-blue mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">Start selling in minutes</span>
          </div>

          {/* Headline */}
          <h2 className="text-3xl md:text-5xl font-bold text-tradeport-dark mb-6">
            Ready to sell your stuff?
          </h2>

          {/* Subheadline */}
          <p className="text-xl text-tradeport-muted mb-10 max-w-2xl mx-auto">
            Post your first ad for just <span className="font-bold text-tradeport-dark">$1</span> and keep 
            <span className="font-bold text-tradeport-dark"> 100%</span> of what you earn. 
            No commissions, no hidden fees.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              onClick={() => setIsListingModalOpen(true)}
              className="relative bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-bold px-8 py-6 rounded-full text-lg transition-all hover:scale-105 shadow-lg group overflow-hidden"
            >
              {/* Pulsing ring effect */}
              <span className="absolute inset-0 rounded-full border-4 border-tradeport-yellow/50 animate-pulse-ring" />
              <span className="relative flex items-center gap-2">
                Sell Now
                <ArrowRight className="w-5 h-5" />
              </span>
            </Button>
            <Button
              variant="outline"
              className="px-8 py-6 rounded-full text-lg font-medium border-2 border-tradeport-dark/20 hover:border-tradeport-dark/40"
              onClick={() => window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' })}
            >
              Browse Marketplace
            </Button>
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap items-center justify-center gap-8 mt-12 pt-8 border-t border-tradeport-border">
            <div className="text-center">
              <p className="text-3xl font-bold text-tradeport-dark">50K+</p>
              <p className="text-sm text-tradeport-muted">Active Listings</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-tradeport-dark">$0</p>
              <p className="text-sm text-tradeport-muted">Commission Fee</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-tradeport-dark">4.9</p>
              <p className="text-sm text-tradeport-muted">Seller Rating</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-tradeport-dark">24/7</p>
              <p className="text-sm text-tradeport-muted">Support</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
