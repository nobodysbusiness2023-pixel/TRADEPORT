import { ShoppingCart, Minus, Plus, Trash2, ArrowRight, Info } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';

export default function Cart() {
  const { 
    cart, 
    isCartOpen, 
    setIsCartOpen, 
    removeFromCart, 
    updateCartQuantity, 
    clearCart, 
    cartTotal,
    cartCount 
  } = useAppContext();

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col">
        <SheetHeader className="pb-4 border-b border-tradeport-border">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2 text-xl">
              <ShoppingCart className="w-5 h-5" />
              Your Cart
              {cartCount > 0 && (
                <Badge className="bg-tradeport-blue text-white">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'}
                </Badge>
              )}
            </SheetTitle>
          </div>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 rounded-full bg-tradeport-light flex items-center justify-center mb-4">
              <ShoppingCart className="w-10 h-10 text-tradeport-muted" />
            </div>
            <h3 className="text-xl font-semibold text-tradeport-dark mb-2">Your cart is empty</h3>
            <p className="text-tradeport-muted mb-6">
              Start shopping to find great deals on amazing products!
            </p>
            <Button
              onClick={() => setIsCartOpen(false)}
              className="bg-tradeport-blue hover:bg-tradeport-dark text-white"
            >
              Continue Shopping
            </Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-3 bg-tradeport-light rounded-xl group"
                >
                  {/* Image */}
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-white flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-tradeport-dark truncate mb-1">
                      {item.title}
                    </h4>
                    <p className="text-sm text-tradeport-muted mb-2">{item.condition}</p>
                    <div className="flex items-center justify-between">
                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="w-8 h-8 rounded-lg bg-white flex items-center justify-center hover:bg-tradeport-border transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 rounded-lg bg-white flex items-center justify-center hover:bg-tradeport-border transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Price */}
                      <span className="font-bold text-tradeport-dark">
                        ${(item.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-tradeport-muted hover:text-tradeport-error transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-tradeport-border pt-4 space-y-4">
              {/* Disclaimer */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">
                  TradePort Market does not handle shipping, payments, warranties, or guarantees. 
                  All transactions are strictly between buyer and seller.
                </p>
              </div>

              {/* Summary */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-tradeport-muted">Subtotal</span>
                  <span className="font-medium">${cartTotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-tradeport-muted">Platform Fee</span>
                  <span className="font-medium text-tradeport-success">$0.00</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-tradeport-border">
                  <span className="font-semibold">Total</span>
                  <span className="text-xl font-bold text-tradeport-dark">
                    ${cartTotal.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Buttons */}
              <div className="space-y-2">
                <Button
                  className="w-full bg-tradeport-blue hover:bg-tradeport-dark text-white font-semibold py-6 rounded-xl"
                  onClick={() => alert('Proceed to checkout with seller directly')}
                >
                  Proceed to Checkout
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setIsCartOpen(false)}
                >
                  Continue Shopping
                </Button>
              </div>

              {/* Clear Cart */}
              <button
                onClick={clearCart}
                className="w-full text-center text-sm text-tradeport-muted hover:text-tradeport-error transition-colors py-2"
              >
                Clear cart
              </button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
