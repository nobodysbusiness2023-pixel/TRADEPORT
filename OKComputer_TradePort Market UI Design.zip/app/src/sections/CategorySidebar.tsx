import { useState } from 'react';
import { 
  Tv, Laptop, Smartphone, ChefHat, Gem, Watch, Shirt, 
  Circle, Home, Wrench, Car, Gamepad2, Puzzle, 
  Book, Music, Heart, PawPrint, Package, ChevronDown, ChevronRight
} from 'lucide-react';
import { categories } from '@/data/products';
import { useAppContext } from '@/store/AppContext';

const iconMap: Record<string, React.ReactNode> = {
  tv: <Tv className="w-5 h-5" />,
  laptop: <Laptop className="w-5 h-5" />,
  smartphone: <Smartphone className="w-5 h-5" />,
  'chef-hat': <ChefHat className="w-5 h-5" />,
  gem: <Gem className="w-5 h-5" />,
  watch: <Watch className="w-5 h-5" />,
  shirt: <Shirt className="w-5 h-5" />,
  circle: <Circle className="w-5 h-5" />,
  home: <Home className="w-5 h-5" />,
  wrench: <Wrench className="w-5 h-5" />,
  car: <Car className="w-5 h-5" />,
  gamepad2: <Gamepad2 className="w-5 h-5" />,
  puzzle: <Puzzle className="w-5 h-5" />,
  book: <Book className="w-5 h-5" />,
  music: <Music className="w-5 h-5" />,
  heart: <Heart className="w-5 h-5" />,
  'paw-print': <PawPrint className="w-5 h-5" />,
  package: <Package className="w-5 h-5" />,
};

export default function CategorySidebar() {
  const { selectedCategory, setSelectedCategory, setFilters, filters } = useAppContext();
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleCategoryClick = (categoryName: string) => {
    setSelectedCategory(categoryName);
    setFilters({ ...filters, category: categoryName });
    window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' });
  };

  return (
    <aside className="w-64 flex-shrink-0 bg-white rounded-xl shadow-card p-6 h-fit sticky top-24">
      <h2 className="text-lg font-bold text-tradeport-dark mb-4 flex items-center gap-2">
        Categories
        <span className="text-xs font-normal text-tradeport-muted bg-tradeport-light px-2 py-0.5 rounded-full">
          {categories.length}
        </span>
      </h2>

      <nav className="space-y-1">
        {categories.map((category) => {
          const isExpanded = expandedCategories.includes(category.id);
          const isActive = selectedCategory === category.name;
          const hasSubcategories = category.subcategories && category.subcategories.length > 0;

          return (
            <div key={category.id}>
              <button
                onClick={() => handleCategoryClick(category.name)}
                onDoubleClick={() => hasSubcategories && toggleCategory(category.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group ${
                  isActive
                    ? 'bg-tradeport-blue text-white'
                    : 'hover:bg-tradeport-light text-tradeport-dark'
                }`}
              >
                <span className={`transition-colors ${isActive ? 'text-white' : 'text-tradeport-muted group-hover:text-tradeport-blue'}`}>
                  {iconMap[category.icon] || <Package className="w-5 h-5" />}
                </span>
                <span className="flex-1 text-left text-sm font-medium">{category.name}</span>
                <span className={`text-xs ${isActive ? 'text-white/70' : 'text-tradeport-muted'}`}>
                  {category.productCount.toLocaleString()}
                </span>
                {hasSubcategories && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleCategory(category.id);
                    }}
                    className={`p-0.5 rounded transition-colors ${
                      isActive ? 'hover:bg-white/20' : 'hover:bg-tradeport-border'
                    }`}
                  >
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>
                )}
              </button>

              {/* Subcategories */}
              {hasSubcategories && isExpanded && (
                <div className="ml-8 mt-1 space-y-1 animate-fade-in">
                  {category.subcategories!.map((sub) => (
                    <button
                      key={sub}
                      onClick={() => {
                        setSelectedCategory(category.name);
                        setFilters({ ...filters, category: category.name });
                      }}
                      className="w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm text-tradeport-muted hover:text-tradeport-blue hover:bg-tradeport-light transition-all text-left"
                    >
                      <span className="w-1 h-1 rounded-full bg-tradeport-border group-hover:bg-tradeport-blue" />
                      {sub}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Clear Filter */}
      {selectedCategory && (
        <button
          onClick={() => {
            setSelectedCategory(null);
            setFilters({ ...filters, category: undefined });
          }}
          className="w-full mt-4 py-2 text-sm text-tradeport-blue hover:text-tradeport-dark font-medium transition-colors"
        >
          Clear filter
        </button>
      )}
    </aside>
  );
}