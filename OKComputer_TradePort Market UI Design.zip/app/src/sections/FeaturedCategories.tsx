import { 
  Tv, Laptop, Smartphone, ChefHat, Gem, Watch, Shirt, 
  Circle, Home, Wrench, Car, Gamepad2, Puzzle, 
  Book, Music, Heart, PawPrint, Package
} from 'lucide-react';
import { categories } from '@/data/products';
import { useAppContext } from '@/store/AppContext';

const iconMap: Record<string, React.ReactNode> = {
  tv: <Tv className="w-8 h-8" />,
  laptop: <Laptop className="w-8 h-8" />,
  smartphone: <Smartphone className="w-8 h-8" />,
  'chef-hat': <ChefHat className="w-8 h-8" />,
  gem: <Gem className="w-8 h-8" />,
  watch: <Watch className="w-8 h-8" />,
  shirt: <Shirt className="w-8 h-8" />,
  circle: <Circle className="w-8 h-8" />,
  home: <Home className="w-8 h-8" />,
  wrench: <Wrench className="w-8 h-8" />,
  car: <Car className="w-8 h-8" />,
  gamepad2: <Gamepad2 className="w-8 h-8" />,
  puzzle: <Puzzle className="w-8 h-8" />,
  book: <Book className="w-8 h-8" />,
  music: <Music className="w-8 h-8" />,
  heart: <Heart className="w-8 h-8" />,
  'paw-print': <PawPrint className="w-8 h-8" />,
  package: <Package className="w-8 h-8" />,
};

export default function FeaturedCategories() {
  const { setSelectedCategory, setFilters, filters } = useAppContext();

  const handleCategoryClick = (categoryName: string) => {
    setSelectedCategory(categoryName);
    setFilters({ ...filters, category: categoryName });
    window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' });
  };

  // Show only first 8 categories for featured section
  const featuredCategories = categories.slice(0, 8);

  return (
    <section className="py-16 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-tradeport-dark mb-4">
            Browse by Category
          </h2>
          <p className="text-tradeport-muted max-w-2xl mx-auto">
            Find exactly what you're looking for across our diverse range of categories
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {featuredCategories.map((category, index) => (
            <button
              key={category.id}
              onClick={() => handleCategoryClick(category.name)}
              className="group flex flex-col items-center p-6 bg-tradeport-light rounded-xl hover:bg-tradeport-blue transition-all duration-300 hover:shadow-lg hover:-translate-y-1 animate-fade-in-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-4 shadow-sm group-hover:bg-white/20 group-hover:text-white text-tradeport-blue transition-all">
                {iconMap[category.icon] || <Package className="w-8 h-8" />}
              </div>
              <h3 className="text-sm font-semibold text-tradeport-dark group-hover:text-white text-center transition-colors">
                {category.name}
              </h3>
              <p className="text-xs text-tradeport-muted group-hover:text-white/70 mt-1 transition-colors">
                {category.productCount.toLocaleString()} items
              </p>
            </button>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-10">
          <button
            onClick={() => window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' })}
            className="inline-flex items-center gap-2 px-6 py-3 bg-tradeport-dark text-white font-medium rounded-full hover:bg-tradeport-blue transition-all hover:scale-105"
          >
            View All Categories
          </button>
        </div>
      </div>
    </section>
  );
}
