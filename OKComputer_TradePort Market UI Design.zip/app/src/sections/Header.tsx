import { useState, useEffect } from 'react';
import { Search, ShoppingCart, User, Menu, X, PlusCircle, Store } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';

export default function Header() {
  const { 
    searchQuery, 
    setSearchQuery, 
    cartCount, 
    setIsCartOpen,
    setIsListingModalOpen,
    setIsSellerDashboardOpen,
    selectedCategory,
    setSelectedCategory
  } = useAppContext();
  
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSellClick = () => {
    setIsListingModalOpen(true);
  };

  const handleDashboardClick = () => {
    setIsSellerDashboardOpen(true);
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-md py-3'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
              isScrolled ? 'bg-tradeport-blue' : 'bg-white'
            }`}>
              <Store className={`w-6 h-6 ${isScrolled ? 'text-white' : 'text-tradeport-blue'}`} />
            </div>
            <div className="hidden sm:block">
              <h1 className={`text-xl font-bold transition-colors duration-300 ${
                isScrolled ? 'text-tradeport-dark' : 'text-white'
              }`}>
                TradePort
              </h1>
              <p className={`text-[10px] -mt-0.5 transition-colors duration-300 ${
                isScrolled ? 'text-tradeport-muted' : 'text-white/70'
              }`}>
                MARKET
              </p>
            </div>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-2xl">
            <div className="relative w-full group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-tradeport-muted transition-colors group-focus-within:text-tradeport-blue" />
              <input
                type="text"
                placeholder="Search for anything..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-12 pr-5 py-3 rounded-full border-2 transition-all duration-300 outline-none ${
                  isScrolled
                    ? 'border-tradeport-border bg-white focus:border-tradeport-blue focus:shadow-lg focus:ring-4 focus:ring-tradeport-blue/10'
                    : 'border-white/30 bg-white/10 text-white placeholder-white/60 focus:border-white focus:bg-white/20'
                }`}
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                    isScrolled ? 'bg-tradeport-light hover:bg-tradeport-border' : 'bg-white/20 hover:bg-white/30'
                  }`}
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            {/* Sell Button - Desktop */}
            <Button
              onClick={handleSellClick}
              className="hidden sm:flex items-center gap-2 bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-semibold rounded-full px-5 transition-all hover:scale-105"
            >
              <PlusCircle className="w-4 h-4" />
              Sell
            </Button>

            {/* Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className={`relative p-2.5 rounded-full transition-all duration-200 ${
                isScrolled
                  ? 'hover:bg-tradeport-light text-tradeport-dark'
                  : 'hover:bg-white/10 text-white'
              }`}
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <Badge className="absolute -top-0.5 -right-0.5 w-5 h-5 flex items-center justify-center p-0 bg-tradeport-blue text-white text-xs animate-bounce-in">
                  {cartCount}
                </Badge>
              )}
            </button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className={`p-2.5 rounded-full transition-all duration-200 ${
                    isScrolled
                      ? 'hover:bg-tradeport-light text-tradeport-dark'
                      : 'hover:bg-white/10 text-white'
                  }`}
                >
                  <User className="w-5 h-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem onClick={handleDashboardClick} className="cursor-pointer">
                  <Store className="w-4 h-4 mr-2" />
                  Seller Dashboard
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <User className="w-4 h-4 mr-2" />
                  My Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  My Purchases
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer text-tradeport-muted">
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`p-2.5 rounded-full transition-all duration-200 md:hidden ${
                isScrolled
                  ? 'hover:bg-tradeport-light text-tradeport-dark'
                  : 'hover:bg-white/10 text-white'
              }`}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 animate-fade-in-up">
            <div className="relative mb-4">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-tradeport-muted" />
              <input
                type="text"
                placeholder="Search for anything..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-5 py-3 rounded-full border-2 border-tradeport-border bg-white focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none"
              />
            </div>
            <Button
              onClick={handleSellClick}
              className="w-full flex items-center justify-center gap-2 bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-semibold rounded-full"
            >
              <PlusCircle className="w-4 h-4" />
              Sell Your Items
            </Button>
          </div>
        )}

        {/* Category Pills - Desktop */}
        {isScrolled && !selectedCategory && (
          <div className="hidden md:flex items-center gap-2 mt-3 overflow-x-auto pb-2 scrollbar-hide">
            {['Electronics', 'Phones', 'Computers', 'Clothing', 'Home', 'Games', 'Sports'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="px-4 py-1.5 text-sm font-medium rounded-full bg-tradeport-light text-tradeport-dark hover:bg-tradeport-blue hover:text-white transition-all duration-200 whitespace-nowrap"
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
