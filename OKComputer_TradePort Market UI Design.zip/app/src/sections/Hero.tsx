import { useEffect, useRef } from 'react';
import { Search, ArrowRight, TrendingUp, Shield, DollarSign } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';

export default function Hero() {
  const { setSearchQuery, searchQuery, setIsListingModalOpen } = useAppContext();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const animate = () => {
      time += 0.005;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Create gradient mesh effect
      for (let i = 0; i < 5; i++) {
        const x = canvas.width * (0.3 + 0.2 * Math.sin(time + i));
        const y = canvas.height * (0.4 + 0.2 * Math.cos(time * 0.7 + i));
        const radius = 300 + 100 * Math.sin(time + i * 0.5);

        const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
        gradient.addColorStop(0, `rgba(0, 86, 211, ${0.15 - i * 0.02})`);
        gradient.addColorStop(0.5, `rgba(0, 86, 211, ${0.08 - i * 0.01})`);
        gradient.addColorStop(1, 'rgba(0, 86, 211, 0)');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      animationId = requestAnimationFrame(animate);
    };

    resize();
    animate();
    window.addEventListener('resize', resize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    window.scrollTo({ top: window.innerHeight - 100, behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-[70vh] md:min-h-[85vh] flex items-center justify-center overflow-hidden bg-tradeport-dark">
      {/* Animated Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ opacity: 0.8 }}
      />

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8 animate-fade-in">
            <TrendingUp className="w-4 h-4 text-tradeport-yellow" />
            <span className="text-white/90 text-sm font-medium">The marketplace built for you</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            Buy and sell
            <span className="block text-tradeport-yellow">without limits</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto mb-10">
            List your items for just $1 per 30 days. No commissions, no hidden fees, no surprises.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
            <div className="relative group">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-tradeport-muted transition-colors group-focus-within:text-tradeport-blue" />
              <input
                type="text"
                placeholder="What are you looking for?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-14 pr-40 py-4 rounded-full bg-white border-2 border-transparent text-tradeport-dark placeholder-tradeport-muted focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none transition-all shadow-2xl"
              />
              <Button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-tradeport-blue hover:bg-tradeport-dark text-white font-semibold rounded-full px-6 py-2.5 transition-all"
              >
                Search
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </form>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Button
              onClick={() => setIsListingModalOpen(true)}
              className="bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-bold px-8 py-6 rounded-full text-lg transition-all hover:scale-105 shadow-lg"
            >
              Start Selling
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-2 border-white/30 text-white hover:bg-white/10 px-8 py-6 rounded-full text-lg font-medium transition-all"
              onClick={() => window.scrollTo({ top: window.innerHeight - 100, behavior: 'smooth' })}
            >
              Browse Items
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-white/60">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-tradeport-yellow" />
              <span className="text-sm font-medium">Verified Sellers</span>
            </div>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-tradeport-yellow" />
              <span className="text-sm font-medium">Zero Commission</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-tradeport-yellow" />
              <span className="text-sm font-medium">50K+ Active Listings</span>
            </div>
          </div>
        </div>
      </div>

      {/* Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
