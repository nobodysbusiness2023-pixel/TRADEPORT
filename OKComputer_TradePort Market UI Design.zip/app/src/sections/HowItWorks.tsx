import { Edit, Search, DollarSign, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/store/AppContext';

const steps = [
  {
    number: 1,
    title: 'Create Your Listing',
    description: 'Upload photos, add details, and set your price. Pay just $1 to list for 30 days.',
    icon: Edit,
    color: 'bg-tradeport-blue',
  },
  {
    number: 2,
    title: 'Get Discovered',
    description: 'Buyers browse and find your items. Our platform makes your listings visible to the right audience.',
    icon: Search,
    color: 'bg-tradeport-yellow',
  },
  {
    number: 3,
    title: 'Make the Sale',
    description: 'Connect directly with buyers to complete the sale. Keep 100% of what you earn.',
    icon: DollarSign,
    color: 'bg-tradeport-success',
  },
];

export default function HowItWorks() {
  const { setIsListingModalOpen } = useAppContext();

  return (
    <section className="py-20 bg-tradeport-light">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-tradeport-dark mb-4">
            How TradePort Works
          </h2>
          <p className="text-tradeport-muted max-w-2xl mx-auto">
            Getting started is easy. List your items, connect with buyers, and keep 100% of your sales.
          </p>
        </div>

        {/* Steps */}
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 relative">
            {/* Connecting Line */}
            <div className="hidden md:block absolute top-24 left-[33%] right-[33%] h-0.5 bg-tradeport-border">
              <div className="h-full bg-tradeport-blue w-0 animate-[widen_1s_ease-out_0.5s_forwards]" 
                style={{ '@keyframes widen': { to: { width: '100%' } } } as React.CSSProperties}
              />
            </div>

            {steps.map((step, index) => (
              <div
                key={step.number}
                className="relative text-center animate-fade-in-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                {/* Icon */}
                <div
                  className={`w-20 h-20 ${step.color} rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg`}
                >
                  <step.icon className={`w-8 h-8 ${step.color === 'bg-tradeport-yellow' ? 'text-tradeport-dark' : 'text-white'}`} />
                </div>

                {/* Content */}
                <div className="bg-white rounded-xl p-6 shadow-card">
                  <div className="w-8 h-8 rounded-full bg-tradeport-light flex items-center justify-center mx-auto mb-4">
                    <span className="font-bold text-tradeport-blue">{step.number}</span>
                  </div>
                  <h3 className="text-xl font-bold text-tradeport-dark mb-3">{step.title}</h3>
                  <p className="text-tradeport-muted">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <Button
            onClick={() => setIsListingModalOpen(true)}
            className="bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-bold px-8 py-6 rounded-full text-lg transition-all hover:scale-105 shadow-lg"
          >
            Start Selling Today
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
