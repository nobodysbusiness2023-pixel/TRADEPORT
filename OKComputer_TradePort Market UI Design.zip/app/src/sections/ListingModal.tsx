import { useState } from 'react';
import { DollarSign, Tag, MapPin, FileText, Check, ImageIcon } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { categories, conditions } from '@/data/products';
import type { UserListing } from '@/types';

interface ListingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ListingModal({ isOpen, onClose }: ListingModalProps) {
  const { createListing } = useAppContext();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [condition, setCondition] = useState('');
  const [location, setLocation] = useState('');
  const [images, setImages] = useState<string[]>([]);

  const totalSteps = 3;

  const handleImageUpload = () => {
    // Simulate image upload
    if (images.length < 5) {
      setImages([...images, `/product-${Math.floor(Math.random() * 24) + 1}.jpg`]);
    }
  };

  const handleSubmit = async () => {
    if (!title || !price || !category || !condition) return;

    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newListing: Omit<UserListing, 'id' | 'status' | 'expiresAt' | 'views' | 'renewals'> = {
      title,
      description,
      price: parseFloat(price),
      image: images[0] || '/product-1.jpg',
      category: categories.find(c => c.id === category)?.name || category,
      condition: condition as any,
      location: location || undefined,
      seller: { name: 'You', rating: 4.9, reviews: 23, verified: true },
      datePosted: new Date().toISOString(),
      tags: [],
      listingFee: 1.00,
    };

    createListing(newListing);
    setIsSubmitting(false);
    setIsSuccess(true);

    setTimeout(() => {
      setIsSuccess(false);
      resetForm();
      onClose();
    }, 2000);
  };

  const resetForm = () => {
    setStep(1);
    setTitle('');
    setDescription('');
    setPrice('');
    setCategory('');
    setCondition('');
    setLocation('');
    setImages([]);
  };

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            Create New Listing
          </DialogTitle>
        </DialogHeader>

        {/* Progress */}
        <div className="flex items-center gap-2 mb-6">
          {Array.from({ length: totalSteps }, (_, i) => (
            <div key={i} className="flex items-center flex-1">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                  i + 1 < step
                    ? 'bg-tradeport-success text-white'
                    : i + 1 === step
                    ? 'bg-tradeport-blue text-white'
                    : 'bg-tradeport-light text-tradeport-muted'
                }`}
              >
                {i + 1 < step ? <Check className="w-4 h-4" /> : i + 1}
              </div>
              {i < totalSteps - 1 && (
                <div
                  className={`flex-1 h-0.5 mx-2 transition-colors ${
                    i + 1 < step ? 'bg-tradeport-success' : 'bg-tradeport-border'
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {isSuccess ? (
          <div className="py-12 text-center">
            <div className="w-20 h-20 rounded-full bg-tradeport-success/10 flex items-center justify-center mx-auto mb-4">
              <Check className="w-10 h-10 text-tradeport-success" />
            </div>
            <h3 className="text-xl font-bold text-tradeport-dark mb-2">Listing Created!</h3>
            <p className="text-tradeport-muted">
              Your item is now live on TradePort Market for 30 days.
            </p>
          </div>
        ) : (
          <>
            {/* Step 1: Basic Info */}
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-tradeport-dark mb-2">
                    Title *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., iPhone 15 Pro Max - Natural Titanium 256GB"
                    className="w-full px-4 py-3 rounded-lg border-2 border-tradeport-border focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-tradeport-dark mb-2">
                    Description
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe your item in detail..."
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border-2 border-tradeport-border focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none transition-all resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-tradeport-dark mb-2">
                      <Tag className="w-4 h-4 inline mr-1" />
                      Category *
                    </label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-tradeport-dark mb-2">
                      Condition *
                    </label>
                    <Select value={condition} onValueChange={setCondition}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent>
                        {conditions.map((cond) => (
                          <SelectItem key={cond} value={cond}>
                            {cond}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-tradeport-dark mb-2">
                      <DollarSign className="w-4 h-4 inline mr-1" />
                      Price *
                    </label>
                    <input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      className="w-full px-4 py-3 rounded-lg border-2 border-tradeport-border focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-tradeport-dark mb-2">
                      <MapPin className="w-4 h-4 inline mr-1" />
                      Location (optional)
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="City, State"
                      className="w-full px-4 py-3 rounded-lg border-2 border-tradeport-border focus:border-tradeport-blue focus:ring-4 focus:ring-tradeport-blue/10 outline-none transition-all"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Images */}
            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-tradeport-dark mb-2">
                    Upload Photos
                  </label>
                  <p className="text-sm text-tradeport-muted mb-4">
                    Add up to 5 photos. First photo will be the main image.
                  </p>

                  {/* Image Grid */}
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                    {images.map((img, index) => (
                      <div
                        key={index}
                        className="aspect-square rounded-lg overflow-hidden bg-tradeport-light border-2 border-tradeport-border"
                      >
                        <img
                          src={img}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                    {images.length < 5 && (
                      <button
                        onClick={handleImageUpload}
                        className="aspect-square rounded-lg bg-tradeport-light border-2 border-dashed border-tradeport-border flex flex-col items-center justify-center gap-2 hover:border-tradeport-blue hover:bg-tradeport-blue/5 transition-all"
                      >
                        <ImageIcon className="w-8 h-8 text-tradeport-muted" />
                        <span className="text-xs text-tradeport-muted">Add Photo</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Preview */}
                {images.length > 0 && (
                  <div>
                    <label className="block text-sm font-medium text-tradeport-dark mb-2">
                      Preview
                    </label>
                    <div className="aspect-video rounded-xl overflow-hidden bg-tradeport-light">
                      <img
                        src={images[0]}
                        alt="Main preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Review & Pay */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="bg-tradeport-light rounded-xl p-6">
                  <h4 className="font-semibold text-tradeport-dark mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Review Your Listing
                  </h4>

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-tradeport-muted">Title:</span>
                      <span className="font-medium text-tradeport-dark">{title || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-tradeport-muted">Category:</span>
                      <span className="font-medium text-tradeport-dark">
                        {categories.find(c => c.id === category)?.name || 'Not set'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-tradeport-muted">Condition:</span>
                      <span className="font-medium text-tradeport-dark">{condition || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-tradeport-muted">Price:</span>
                      <span className="font-medium text-tradeport-dark">${price || '0.00'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-tradeport-muted">Location:</span>
                      <span className="font-medium text-tradeport-dark">{location || 'Not set'}</span>
                    </div>
                  </div>
                </div>

                {/* Fee Info */}
                <div className="bg-tradeport-yellow/10 border border-tradeport-yellow/30 rounded-xl p-4">
                  <h4 className="font-semibold text-tradeport-dark mb-2">Listing Fee</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-tradeport-muted">30-day listing</span>
                    <span className="text-2xl font-bold text-tradeport-dark">$1.00</span>
                  </div>
                  <p className="text-sm text-tradeport-muted mt-2">
                    No commissions, no hidden fees. Just a flat $1 fee per listing every 30 days.
                  </p>
                </div>

                {/* Terms */}
                <div className="text-sm text-tradeport-muted">
                  <p className="mb-2">
                    By creating this listing, you agree to our terms of service and acknowledge that:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>TradePort Market does not handle payments, shipping, or warranties</li>
                    <li>All transactions are between you and the buyer directly</li>
                    <li>You are responsible for accurate item descriptions</li>
                    <li>The $1 listing fee is non-refundable</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between pt-6 border-t border-tradeport-border">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={step === 1}
                className={step === 1 ? 'invisible' : ''}
              >
                Previous
              </Button>

              {step < totalSteps ? (
                <Button
                  onClick={nextStep}
                  disabled={
                    (step === 1 && (!title || !price || !category || !condition)) ||
                    (step === 2 && images.length === 0)
                  }
                  className="bg-tradeport-blue hover:bg-tradeport-dark text-white"
                >
                  Next
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-bold"
                >
                  {isSubmitting ? (
                    'Processing...'
                  ) : (
                    <>Pay $1.00 & Publish</>
                  )}
                </Button>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
