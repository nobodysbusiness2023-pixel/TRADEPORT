import { useState } from 'react';
import { ShoppingCart, MapPin, User, Star, MessageCircle, Heart, Share2, Check } from 'lucide-react';
import type { Product } from '@/types';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProductDetailModal({ product, isOpen, onClose }: ProductDetailModalProps) {
  const { addToCart } = useAppContext();
  const [isAdded, setIsAdded] = useState(false);

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const getConditionBadge = (condition: string) => {
    switch (condition) {
      case 'New':
        return <Badge className="badge-new text-sm px-3 py-1">New</Badge>;
      case 'Used':
        return <Badge className="badge-used text-sm px-3 py-1">Used</Badge>;
      case 'Refurbished':
        return <Badge className="badge-refurbished text-sm px-3 py-1">Refurbished</Badge>;
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto p-0 gap-0">
        <div className="grid md:grid-cols-2 gap-0">
          {/* Image Section */}
          <div className="bg-tradeport-light p-6">
            <div className="aspect-square rounded-xl overflow-hidden bg-white mb-4">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Tags */}
            {product.tags && product.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-white rounded-full text-sm text-tradeport-muted"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Details Section */}
          <div className="p-6 flex flex-col">
            <DialogHeader className="mb-4">
              <div className="flex items-center gap-3 mb-2">
                {getConditionBadge(product.condition)}
                {product.featured && (
                  <Badge className="bg-tradeport-blue text-white">Featured</Badge>
                )}
              </div>
              <DialogTitle className="text-2xl font-bold text-tradeport-dark">
                {product.title}
              </DialogTitle>
            </DialogHeader>

            {/* Price */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl font-bold text-tradeport-dark">
                ${product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <>
                  <span className="text-xl text-tradeport-muted line-through">
                    ${product.originalPrice.toLocaleString()}
                  </span>
                  <Badge className="bg-tradeport-success/10 text-tradeport-success">
                    Save ${(product.originalPrice - product.price).toLocaleString()}
                  </Badge>
                </>
              )}
            </div>

            {/* Category & Location */}
            <div className="flex flex-wrap gap-4 mb-6 text-sm">
              <div className="flex items-center gap-2 text-tradeport-muted">
                <span className="font-medium">Category:</span>
                <span className="text-tradeport-blue font-medium">{product.category}</span>
              </div>
              {product.location && (
                <div className="flex items-center gap-2 text-tradeport-muted">
                  <MapPin className="w-4 h-4" />
                  <span>{product.location}</span>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h4 className="font-semibold text-tradeport-dark mb-2">Description</h4>
              <p className="text-tradeport-muted leading-relaxed">{product.description}</p>
            </div>

            {/* Seller Info */}
            <div className="bg-tradeport-light rounded-xl p-4 mb-6">
              <h4 className="font-semibold text-tradeport-dark mb-3">Seller Information</h4>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center">
                    <User className="w-6 h-6 text-tradeport-muted" />
                  </div>
                  <div>
                    <p className="font-semibold text-tradeport-dark">{product.seller.name}</p>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-tradeport-yellow text-tradeport-yellow" />
                        <span className="font-medium">{product.seller.rating}</span>
                      </div>
                      <span className="text-tradeport-muted">({product.seller.reviews} reviews)</span>
                      {product.seller.verified && (
                        <Badge className="bg-tradeport-success/10 text-tradeport-success text-xs">
                          Verified
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Contact
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 mt-auto">
              <Button
                onClick={handleAddToCart}
                className={`flex-1 font-semibold py-6 rounded-xl transition-all ${
                  isAdded
                    ? 'bg-tradeport-success hover:bg-tradeport-success'
                    : 'bg-tradeport-blue hover:bg-tradeport-dark'
                }`}
              >
                {isAdded ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Added to Cart
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center gap-2 px-4"
              >
                <Heart className="w-5 h-5" />
              </Button>
              <Button
                variant="outline"
                className="flex items-center justify-center gap-2 px-4"
              >
                <Share2 className="w-5 h-5" />
              </Button>
            </div>

            {/* Disclaimer */}
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-xs text-amber-700">
                <strong>Important:</strong> TradePort Market does not handle shipping, payments, warranties, or guarantees. 
                All transactions are strictly between buyer and seller.
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
