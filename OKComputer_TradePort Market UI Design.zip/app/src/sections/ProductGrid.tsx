import { useState } from 'react';
import { ShoppingCart, MapPin, User, Star, Filter, Grid3X3, LayoutGrid, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { Product } from '@/types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const getConditionBadge = (condition: string) => {
    switch (condition) {
      case 'New':
        return <Badge className="badge-new">New</Badge>;
      case 'Used':
        return <Badge className="badge-used">Used</Badge>;
      case 'Refurbished':
        return <Badge className="badge-refurbished">Refurbished</Badge>;
      default:
        return null;
    }
  };

  return (
    <div
      className="group bg-white rounded-xl overflow-hidden shadow-card transition-all duration-300 hover:shadow-card-hover hover:-translate-y-2 cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onViewDetails(product)}
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-tradeport-light">
        {!imageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-r from-tradeport-light via-white to-tradeport-light animate-pulse" />
        )}
        <img
          src={product.image}
          alt={product.title}
          className={`w-full h-full object-cover transition-transform duration-500 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          } ${isHovered ? 'scale-110' : 'scale-100'}`}
          onLoad={() => setImageLoaded(true)}
        />

        {/* Condition Badge */}
        <div className="absolute top-3 left-3">
          {getConditionBadge(product.condition)}
        </div>

        {/* Featured Badge */}
        {product.featured && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-tradeport-blue text-white text-xs">
              Featured
            </Badge>
          </div>
        )}

        {/* Quick Add Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onAddToCart(product);
          }}
          className={`absolute bottom-3 right-3 bg-tradeport-blue text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:bg-tradeport-dark hover:scale-110 ${
            isHovered ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
          }`}
        >
          <ShoppingCart className="w-5 h-5" />
        </button>

        {/* Price Tag Overlay */}
        {product.originalPrice && (
          <div className="absolute bottom-3 left-3 bg-tradeport-dark/80 text-white px-3 py-1 rounded-lg backdrop-blur-sm">
            <span className="text-sm line-through opacity-70">${product.originalPrice}</span>
            <span className="ml-2 font-bold text-tradeport-yellow">
              {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category */}
        <p className="text-xs text-tradeport-muted mb-1">{product.category}</p>

        {/* Title */}
        <h3 className="font-semibold text-tradeport-dark mb-2 line-clamp-2 group-hover:text-tradeport-blue transition-colors">
          {product.title}
        </h3>

        {/* Price */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xl font-bold text-tradeport-dark">
            ${product.price.toLocaleString()}
          </span>
        </div>

        {/* Location */}
        {product.location && (
          <div className="flex items-center gap-1 text-tradeport-muted text-sm mb-3">
            <MapPin className="w-3.5 h-3.5" />
            <span>{product.location}</span>
          </div>
        )}

        {/* Seller Info */}
        <div className="flex items-center justify-between pt-3 border-t border-tradeport-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-tradeport-light flex items-center justify-center">
              <User className="w-4 h-4 text-tradeport-muted" />
            </div>
            <div>
              <p className="text-xs font-medium text-tradeport-dark">{product.seller.name}</p>
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-tradeport-yellow text-tradeport-yellow" />
                <span className="text-xs text-tradeport-muted">{product.seller.rating}</span>
                <span className="text-xs text-tradeport-muted">({product.seller.reviews})</span>
              </div>
            </div>
          </div>

          {product.seller.verified && (
            <Badge variant="secondary" className="text-xs bg-tradeport-success/10 text-tradeport-success">
              Verified
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

interface ProductGridProps {
  onViewDetails: (product: Product) => void;
}

export default function ProductGrid({ onViewDetails }: ProductGridProps) {
  const { filteredProducts, addToCart, setFilters, selectedCategory, filters } = useAppContext();
  const [viewMode, setViewMode] = useState<'grid' | 'large'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const itemsPerPage = viewMode === 'grid' ? 12 : 6;

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const displayedProducts = filteredProducts.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' });
  };

  return (
    <div className="flex-1">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-tradeport-dark">
            {selectedCategory || 'All Products'}
          </h2>
          <p className="text-tradeport-muted mt-1">
            {filteredProducts.length} items found
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Filter Button - Mobile */}
          <Button
            variant="outline"
            className="sm:hidden flex items-center gap-2"
            onClick={() => setIsFilterOpen(true)}
          >
            <Filter className="w-4 h-4" />
            Filters
          </Button>

          {/* Sort */}
          <Select
            onValueChange={(value) => setFilters({ ...filters, sortBy: value as any })}
            defaultValue="featured"
          >
            <SelectTrigger className="w-44">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>

          {/* View Mode */}
          <div className="hidden sm:flex items-center gap-1 bg-tradeport-light rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-all ${
                viewMode === 'grid' ? 'bg-white shadow-sm text-tradeport-blue' : 'text-tradeport-muted'
              }`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('large')}
              className={`p-2 rounded-md transition-all ${
                viewMode === 'large' ? 'bg-white shadow-sm text-tradeport-blue' : 'text-tradeport-muted'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {isFilterOpen && (
        <div className="fixed inset-0 z-50 sm:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsFilterOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-xl p-6 animate-slide-in-right overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold">Filters</h3>
              <button onClick={() => setIsFilterOpen(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            {/* Add filter options here */}
          </div>
        </div>
      )}

      {/* Products Grid */}
      {displayedProducts.length > 0 ? (
        <>
          <div className={`grid gap-4 sm:gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
              : 'grid-cols-1 md:grid-cols-2'
          }`}>
            {displayedProducts.map((product, index) => (
              <div
                key={product.id}
                className="animate-fade-in-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <ProductCard
                  product={product}
                  onAddToCart={addToCart}
                  onViewDetails={onViewDetails}
                />
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-10">
              <button
                onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg hover:bg-tradeport-light disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={`w-10 h-10 rounded-lg font-medium transition-all ${
                    currentPage === page
                      ? 'bg-tradeport-blue text-white'
                      : 'hover:bg-tradeport-light'
                  }`}
                >
                  {page}
                </button>
              ))}

              <button
                onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="p-2 rounded-lg hover:bg-tradeport-light disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-24 h-24 rounded-full bg-tradeport-light flex items-center justify-center mb-4">
            <ShoppingCart className="w-10 h-10 text-tradeport-muted" />
          </div>
          <h3 className="text-xl font-semibold text-tradeport-dark mb-2">No products found</h3>
          <p className="text-tradeport-muted text-center max-w-md">
            Try adjusting your search or filters to find what you're looking for.
          </p>
        </div>
      )}
    </div>
  );
}
