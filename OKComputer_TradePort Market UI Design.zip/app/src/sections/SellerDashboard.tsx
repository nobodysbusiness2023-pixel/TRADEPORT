import { Plus, Clock, Eye, RefreshCw, DollarSign, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { useAppContext } from '@/store/AppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import type { UserListing } from '@/types';

interface SellerDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateListing: () => void;
}

function formatTimeLeft(expiresAt: string) {
  const now = new Date();
  const expiry = new Date(expiresAt);
  const diff = expiry.getTime() - now.getTime();

  if (diff <= 0) return { text: 'Expired', color: 'text-tradeport-error' };

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  if (days > 0) {
    return { text: `${days} days left`, color: 'text-tradeport-success' };
  }
  return { text: `${hours} hours left`, color: 'text-tradeport-yellow' };
}

function ListingCard({ listing, onRenew }: { listing: UserListing; onRenew: (id: string) => void }) {
  const timeLeft = formatTimeLeft(listing.expiresAt);

  return (
    <div className="bg-white rounded-xl p-4 shadow-card border border-tradeport-border hover:shadow-card-hover transition-all">
      <div className="flex gap-4">
        {/* Image */}
        <div className="w-24 h-24 rounded-lg overflow-hidden bg-tradeport-light flex-shrink-0">
          <img
            src={listing.image}
            alt={listing.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Details */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h4 className="font-semibold text-tradeport-dark truncate">{listing.title}</h4>
              <p className="text-sm text-tradeport-muted mt-1">{listing.category}</p>
            </div>
            <Badge
              className={`${
                listing.status === 'Active'
                  ? 'bg-tradeport-success/10 text-tradeport-success'
                  : 'bg-tradeport-error/10 text-tradeport-error'
              }`}
            >
              {listing.status}
            </Badge>
          </div>

          <div className="flex items-center gap-4 mt-3 text-sm">
            <div className="flex items-center gap-1">
              <DollarSign className="w-4 h-4 text-tradeport-muted" />
              <span className="font-semibold">${listing.price.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-1 text-tradeport-muted">
              <Eye className="w-4 h-4" />
              <span>{listing.views} views</span>
            </div>
            <div className={`flex items-center gap-1 ${timeLeft.color}`}>
              <Clock className="w-4 h-4" />
              <span>{timeLeft.text}</span>
            </div>
          </div>

          {/* Actions */}
          {listing.status === 'Expired' && (
            <div className="mt-3 flex gap-2">
              <Button
                size="sm"
                onClick={() => onRenew(listing.id)}
                className="bg-tradeport-blue hover:bg-tradeport-dark text-white"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Renew for $1
              </Button>
            </div>
          )}

          {listing.status === 'Active' && (
            <div className="mt-3 flex gap-2">
              <Button variant="outline" size="sm">
                Edit
              </Button>
              <Button variant="outline" size="sm" className="text-tradeport-error">
                Delete
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function SellerDashboard({ isOpen, onClose, onCreateListing }: SellerDashboardProps) {
  const { userListings, renewListing } = useAppContext();

  const activeListings = userListings.filter(l => l.status === 'Active');
  const expiredListings = userListings.filter(l => l.status === 'Expired');
  const totalViews = userListings.reduce((sum, l) => sum + l.views, 0);
  const totalFees = userListings.reduce((sum, l) => sum + (l.renewals + 1) * l.listingFee, 0);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-3xl flex flex-col">
        <SheetHeader className="pb-4 border-b border-tradeport-border">
          <SheetTitle className="text-2xl flex items-center gap-2">
            <TrendingUp className="w-6 h-6" />
            Seller Dashboard
          </SheetTitle>
        </SheetHeader>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-6">
          <div className="bg-tradeport-light rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-tradeport-success" />
              <span className="text-sm text-tradeport-muted">Active</span>
            </div>
            <p className="text-2xl font-bold text-tradeport-dark">{activeListings.length}</p>
          </div>
          <div className="bg-tradeport-light rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-5 h-5 text-tradeport-error" />
              <span className="text-sm text-tradeport-muted">Expired</span>
            </div>
            <p className="text-2xl font-bold text-tradeport-dark">{expiredListings.length}</p>
          </div>
          <div className="bg-tradeport-light rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Eye className="w-5 h-5 text-tradeport-blue" />
              <span className="text-sm text-tradeport-muted">Total Views</span>
            </div>
            <p className="text-2xl font-bold text-tradeport-dark">{totalViews.toLocaleString()}</p>
          </div>
          <div className="bg-tradeport-light rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-5 h-5 text-tradeport-yellow" />
              <span className="text-sm text-tradeport-muted">Fees Paid</span>
            </div>
            <p className="text-2xl font-bold text-tradeport-dark">${totalFees.toFixed(2)}</p>
          </div>
        </div>

        {/* Create Listing Button */}
        <Button
          onClick={onCreateListing}
          className="w-full bg-tradeport-yellow hover:bg-tradeport-yellow/90 text-tradeport-dark font-bold py-6 rounded-xl mb-6"
        >
          <Plus className="w-5 h-5 mr-2" />
          Create New Listing
        </Button>

        {/* Listings */}
        <div className="flex-1 overflow-y-auto space-y-4">
          {/* Active Listings */}
          {activeListings.length > 0 && (
            <div>
              <h3 className="font-semibold text-tradeport-dark mb-3">Active Listings</h3>
              <div className="space-y-3">
                {activeListings.map((listing) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    onRenew={renewListing}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Expired Listings */}
          {expiredListings.length > 0 && (
            <div>
              <h3 className="font-semibold text-tradeport-dark mb-3">Expired Listings</h3>
              <div className="space-y-3">
                {expiredListings.map((listing) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    onRenew={renewListing}
                  />
                ))}
              </div>
            </div>
          )}

          {userListings.length === 0 && (
            <div className="text-center py-12">
              <div className="w-20 h-20 rounded-full bg-tradeport-light flex items-center justify-center mx-auto mb-4">
                <Plus className="w-8 h-8 text-tradeport-muted" />
              </div>
              <h4 className="text-lg font-semibold text-tradeport-dark mb-2">No listings yet</h4>
              <p className="text-tradeport-muted mb-4">
                Start selling your items for just $1 per listing
              </p>
              <Button
                onClick={onCreateListing}
                className="bg-tradeport-blue hover:bg-tradeport-dark text-white"
              >
                Create Your First Listing
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
