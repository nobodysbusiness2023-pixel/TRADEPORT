import { Quote, Star } from 'lucide-react';
import { testimonials } from '@/data/products';

export default function Testimonials() {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-tradeport-dark mb-4">
            What our users say
          </h2>
          <p className="text-tradeport-muted max-w-2xl mx-auto">
            Join thousands of satisfied buyers and sellers on TradePort Market
          </p>
        </div>

        {/* Testimonials Marquee */}
        <div className="relative">
          {/* Gradient Overlays */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white to-transparent z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white to-transparent z-10" />

          {/* Scrolling Container */}
          <div className="flex animate-marquee">
            {/* First Set */}
            {testimonials.map((testimonial, index) => (
              <div
                key={`first-${index}`}
                className="flex-shrink-0 w-96 mx-4 animate-fade-in"
              >
                <div className="bg-tradeport-light rounded-2xl p-6 h-full">
                  <Quote className="w-10 h-10 text-tradeport-blue/20 mb-4" />
                  <p className="text-tradeport-dark mb-6 leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-tradeport-blue text-white flex items-center justify-center font-bold">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-tradeport-dark">{testimonial.name}</p>
                      <p className="text-sm text-tradeport-muted">{testimonial.company}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 mt-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-tradeport-yellow text-tradeport-yellow" />
                    ))}
                  </div>
                </div>
              </div>
            ))}

            {/* Duplicate Set for Seamless Loop */}
            {testimonials.map((testimonial, index) => (
              <div
                key={`second-${index}`}
                className="flex-shrink-0 w-96 mx-4"
              >
                <div className="bg-tradeport-light rounded-2xl p-6 h-full">
                  <Quote className="w-10 h-10 text-tradeport-blue/20 mb-4" />
                  <p className="text-tradeport-dark mb-6 leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-tradeport-blue text-white flex items-center justify-center font-bold">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-tradeport-dark">{testimonial.name}</p>
                      <p className="text-sm text-tradeport-muted">{testimonial.company}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 mt-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-tradeport-yellow text-tradeport-yellow" />
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
