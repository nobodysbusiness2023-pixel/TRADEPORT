import { useState } from 'react';
import { 
  Percent, Users, Shield, Heart, 
  ChevronDown, ChevronUp, CheckCircle 
} from 'lucide-react';

const benefits = [
  {
    title: 'Zero Commission',
    description: 'Keep 100% of your sales. We only charge a flat $1 listing fee per item every 30 days. No hidden fees, no surprises.',
    icon: Percent,
  },
  {
    title: 'Direct Buyer-Seller Connection',
    description: 'Communicate directly with buyers. No middleman means better prices for everyone and faster transactions.',
    icon: Users,
  },
  {
    title: 'Simple & Transparent',
    description: 'No complex pricing tiers or confusing fee structures. One flat fee, that\'s it. What you see is what you pay.',
    icon: Shield,
  },
  {
    title: 'Built for Everyone',
    description: 'Whether you\'re a casual seller decluttering your home or a business moving inventory, our platform works for you.',
    icon: Heart,
  },
];

export default function WhyChooseUs() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  return (
    <section className="py-20 bg-tradeport-dark text-white">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Content */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Why sellers love
              <span className="text-tradeport-yellow"> TradePort</span>
            </h2>
            <p className="text-white/70 text-lg mb-8">
              We built TradePort Market because we believe selling online should be simple, 
              affordable, and transparent. Here's what makes us different:
            </p>

            {/* Benefits Accordion */}
            <div className="space-y-3">
              {benefits.map((benefit, index) => {
                const isExpanded = expandedIndex === index;
                const Icon = benefit.icon;

                return (
                  <div
                    key={index}
                    className={`rounded-xl transition-all duration-300 ${
                      isExpanded ? 'bg-white/10' : 'bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <button
                      onClick={() => setExpandedIndex(isExpanded ? null : index)}
                      className="w-full flex items-center gap-4 p-4 text-left"
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                        isExpanded ? 'bg-tradeport-yellow text-tradeport-dark' : 'bg-white/10 text-white'
                      }`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-semibold flex-1">{benefit.title}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5" />
                      ) : (
                        <ChevronDown className="w-5 h-5" />
                      )}
                    </button>

                    {isExpanded && (
                      <div className="px-4 pb-4 pl-[72px]">
                        <p className="text-white/70">{benefit.description}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right - Visual */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Background Circle */}
              <div className="absolute inset-0 rounded-full bg-tradeport-blue/20 blur-3xl" />
              
              {/* Stats Cards */}
              <div className="relative grid grid-cols-2 gap-4">
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 animate-fade-in-up">
                  <CheckCircle className="w-10 h-10 text-tradeport-yellow mb-4" />
                  <p className="text-3xl font-bold mb-1">$1</p>
                  <p className="text-white/70">Flat fee per listing</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 animate-fade-in-up" style={{ animationDelay: '100ms' }}>
                  <CheckCircle className="w-10 h-10 text-tradeport-yellow mb-4" />
                  <p className="text-3xl font-bold mb-1">0%</p>
                  <p className="text-white/70">Commission on sales</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                  <CheckCircle className="w-10 h-10 text-tradeport-yellow mb-4" />
                  <p className="text-3xl font-bold mb-1">100%</p>
                  <p className="text-white/70">Of sales you keep</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 animate-fade-in-up" style={{ animationDelay: '300ms' }}>
                  <CheckCircle className="w-10 h-10 text-tradeport-yellow mb-4" />
                  <p className="text-3xl font-bold mb-1">30</p>
                  <p className="text-white/70">Days per listing</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
