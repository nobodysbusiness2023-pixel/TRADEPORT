import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import type { Product, CartItem, UserListing, Filters } from '@/types';
import { products as initialProducts, userListings as initialUserListings } from '@/data/products';

interface AppContextType {
  products: Product[];
  cart: CartItem[];
  userListings: UserListing[];
  filters: Filters;
  searchQuery: string;
  selectedCategory: string | null;
  isCartOpen: boolean;
  isListingModalOpen: boolean;
  isSellerDashboardOpen: boolean;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: string | null) => void;
  setFilters: (filters: Filters) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsListingModalOpen: (open: boolean) => void;
  setIsSellerDashboardOpen: (open: boolean) => void;
  createListing: (listing: Omit<UserListing, 'id' | 'status' | 'expiresAt' | 'views' | 'renewals'>) => void;
  renewListing: (listingId: string) => void;
  filteredProducts: Product[];
  cartTotal: number;
  cartCount: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [products] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [userListings, setUserListings] = useState<UserListing[]>(initialUserListings);
  const [filters, setFilters] = useState<Filters>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);
  const [isSellerDashboardOpen, setIsSellerDashboardOpen] = useState(false);

  const addToCart = useCallback((product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  }, []);

  const updateCartQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const createListing = useCallback((listing: Omit<UserListing, 'id' | 'status' | 'expiresAt' | 'views' | 'renewals'>) => {
    const newListing: UserListing = {
      ...listing,
      id: `ul${Date.now()}`,
      status: 'Active',
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      views: 0,
      renewals: 0,
      seller: { name: 'You', rating: 4.9, reviews: 23, verified: true },
    };
    setUserListings(prev => [...prev, newListing]);
  }, []);

  const renewListing = useCallback((listingId: string) => {
    setUserListings(prev =>
      prev.map(listing =>
        listing.id === listingId
          ? {
              ...listing,
              renewals: listing.renewals + 1,
              expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
              status: 'Active' as const,
            }
          : listing
      )
    );
  }, []);

  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        product =>
          product.title.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query) ||
          product.tags?.some(tag => tag.toLowerCase().includes(query)) ||
          product.category.toLowerCase().includes(query)
      );
    }

    // Category filter
    if (selectedCategory) {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    // Condition filter
    if (filters.condition && filters.condition.length > 0) {
      filtered = filtered.filter(product => filters.condition!.includes(product.condition));
    }

    // Price filter
    if (filters.priceRange) {
      filtered = filtered.filter(
        product =>
          product.price >= filters.priceRange![0] &&
          product.price <= filters.priceRange![1]
      );
    }

    // Sort
    switch (filters.sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        filtered.sort(
          (a, b) => new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime()
        );
        break;
      case 'featured':
      default:
        filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    return filtered;
  }, [products, searchQuery, selectedCategory, filters]);

  const cartTotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [cart]
  );

  const cartCount = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  const value = useMemo(
    () => ({
      products,
      cart,
      userListings,
      filters,
      searchQuery,
      selectedCategory,
      isCartOpen,
      isListingModalOpen,
      isSellerDashboardOpen,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      setSearchQuery,
      setSelectedCategory,
      setFilters,
      setIsCartOpen,
      setIsListingModalOpen,
      setIsSellerDashboardOpen,
      createListing,
      renewListing,
      filteredProducts,
      cartTotal,
      cartCount,
    }),
    [
      products,
      cart,
      userListings,
      filters,
      searchQuery,
      selectedCategory,
      isCartOpen,
      isListingModalOpen,
      isSellerDashboardOpen,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      createListing,
      renewListing,
      filteredProducts,
      cartTotal,
      cartCount,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
