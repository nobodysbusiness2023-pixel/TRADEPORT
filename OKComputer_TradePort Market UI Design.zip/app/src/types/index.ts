export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  condition: 'New' | 'Used' | 'Refurbished';
  location?: string;
  seller: {
    name: string;
    rating: number;
    reviews: number;
    verified: boolean;
  };
  datePosted: string;
  featured?: boolean;
  tags?: string[];
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  productCount: number;
  subcategories?: string[];
}

export interface UserListing extends Product {
  status: 'Active' | 'Expired' | 'Draft';
  expiresAt: string;
  views: number;
  renewals: number;
  listingFee: number;
}

export interface Testimonial {
  id: string;
  name: string;
  company: string;
  quote: string;
  avatar: string;
}

export interface BannerItem {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  cta: string;
  link: string;
}

export type SortOption = 'newest' | 'price-low' | 'price-high' | 'featured';

export interface Filters {
  category?: string;
  condition?: string[];
  priceRange?: [number, number];
  location?: string;
  sortBy?: SortOption;
  searchQuery?: string;
}
